/* portable.h is widely used, so we redirect to a less conflicting name. */
#include "portable_basic.h"
